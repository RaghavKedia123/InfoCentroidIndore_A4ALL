class NewPasswordScreenEntity {
  final String mobileNumber;

  const NewPasswordScreenEntity({required this.mobileNumber});
}
