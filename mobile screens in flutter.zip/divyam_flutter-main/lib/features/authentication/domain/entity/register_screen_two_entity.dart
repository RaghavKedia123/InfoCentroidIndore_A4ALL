class RegisterScreenTwoEntity {
  final String mobileNumber;
  final String? referralCode;

  RegisterScreenTwoEntity({required this.mobileNumber, this.referralCode});
}
