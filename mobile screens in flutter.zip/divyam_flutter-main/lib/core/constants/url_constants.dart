const String BASE_URL = 'http://74.208.14.162/api';

// Authentication
// ignore: constant_identifier_names
const String GENRATE_OTP_URL = '$BASE_URL/generateotp';
// ignore: constant_identifier_names
const String SIGN_IN_URL = '$BASE_URL/userlogin';
// ignore: constant_identifier_names
const String GET_ALL_STATES_URL = '$BASE_URL/all_state';

const String REGISTER_URL = '$BASE_URL/register';

const String FORGOT_PASSWORD_URL = '$BASE_URL/forgetmobile';

const String FORGOT_PASSWORD_SENDOTP_URL = '$BASE_URL/forgetsendOtp';

const String PASSWORD_UPDATE_URL = '$BASE_URL/passwordupdate';
