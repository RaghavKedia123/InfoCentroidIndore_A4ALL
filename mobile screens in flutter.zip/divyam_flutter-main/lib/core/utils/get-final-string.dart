String getFinalLabel(String text) {
  // You can manipulate the text here if needed
  return text; // Example: converting text to uppercase
}
